# -*- coding: utf-8 -*-
from setuptools import setup

packages = \
['vpn_routes', 'vpn_routes.funcs']

package_data = \
{'': ['*']}

install_requires = \
['paramiko>=2.12.0,<3.0.0']

entry_points = \
{'console_scripts': ['vpn-routes = vpn_routes.main:main']}

setup_kwargs = {
    'name': 'vpn-routes',
    'version': '0.1.0',
    'description': 'Designated to add new static routes to FRR via SSH connection',
    'long_description': '## VPN Routes\n\nUsed to add new static routes to FRR installed on VPS via establishing SSH connection.\n',
    'author': 'modemfux',
    'author_email': 'modemfux@gmail.com',
    'maintainer': 'None',
    'maintainer_email': 'None',
    'url': 'None',
    'packages': packages,
    'package_data': package_data,
    'install_requires': install_requires,
    'entry_points': entry_points,
    'python_requires': '>=3.8.1,<4.0.0',
}


setup(**setup_kwargs)
