## VPN Routes

Used to add new static routes to FRR installed on VPS via establishing SSH connection.
